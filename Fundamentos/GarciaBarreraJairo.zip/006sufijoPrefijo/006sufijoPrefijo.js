/* 006sufijoPrefijo.js/.html: ¿Cuáles son los valores finales de todas las variables a, b, c y 
d después del código a continuación?
let a = 1, b = 1;
let c = ++a; // ? 2 , ya que el incremento se efectúa antes de terminar la ejecución de la sentencia.
let d = b++; // ? 1 , debido a que el incremento se efectúa después de la ejecución de la sentencia.
*/

