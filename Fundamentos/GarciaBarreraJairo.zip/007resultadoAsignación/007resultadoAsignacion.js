/*007resultadoAsignación.js/.html ¿Cuáles son los valores de ‘a’ y ‘x’ después del código 
a continuación?
let a = 2;
let x = 1 + (a *= 2);
*/
"use strict";
let a = 2;
//*  a*=2 es lo mismo que a = a * a  -> 4

let x = 1 + (a *= 2); //? El resultado será 5 -> ( 1 + 2 * 2)
