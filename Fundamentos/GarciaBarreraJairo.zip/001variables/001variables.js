/*001variables.js/.html: Declara dos variables: admin y name.
Asigna el valor "John Snow" a name.
Copia el valor de name a admin.
Muestra el valor de admin usando alert (debe salir “John Snow”).*/
"use strict";
//utilizo nombres más específicos en las variables, ya que admin y name son demasiado ambiguos y genéricos
let userName = "John Snow";
let adminName = userName;

alert(adminName);
