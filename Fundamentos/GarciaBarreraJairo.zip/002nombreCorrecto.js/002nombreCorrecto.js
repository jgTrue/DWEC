/*002nombreCorrecto.js/.html: Crea una variable con el nombre de nuestra ciudad. 
¿Cómo nombrarías a dicha variable?
Crea una variable para almacenar el nombre del usuario actual de un sitio web. ¿Cómo 
nombrarías a dicha variable?*/
"use strict";
let userCity; // Ya que es la ciudad del usuario en cuestión

let userName; // Indica claramente que contiene, "user name"