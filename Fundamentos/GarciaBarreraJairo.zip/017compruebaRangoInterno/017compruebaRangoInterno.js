/*
017compruebaRangoInterno.js/.html: Escribe una condición “if” para comprobar que 
age(edad) está entre 18 y 99 inclusive. “Inclusive” significa que age puede llegar a ser 
uno de los extremos, 18 o 99.
*/
"use strict";
let edad = prompt("Introduce tu edad") //Recoge el valor de edad


if(edad >= 18 && edad <= 99 ) alert("Edad correcta");//Comprueba que edad esté comprendida entre 18 y 99 inclusive
    
