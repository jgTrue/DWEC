/*011ifStringCero.js/.html: ¿Se mostrará el alert?
if ("0") {
  alert( '¿me ejecuto o no?' );
}*/
//? Si se ejecuta ya que es un string definido por tanto es evaludo como true, debería esta vacío para que sucediera lo contrario
